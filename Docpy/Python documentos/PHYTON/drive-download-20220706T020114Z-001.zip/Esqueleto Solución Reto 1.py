import math

area =  # Aqui debes leer el area de la zona y transformarla a float
ant_old = int(input())
type_new = input()
area_old =  # Aqui debes asignar el valor del rango de las antenas previamente instaladas

if ant_old >= 0:
    if type_new == 'a':
        print(max(0, math.ceil((area - area_old * ant_old) / 11400)))
    elif type_new == 'b':
        print(max(0, math.ceil(   )))  # Aqui debes realizar el calculo de las antenas de tipo b con su rango respectivo
    elif type_new == 'c':
        print(max(0, math.ceil(   )))  # Aqui debes realizar el calculo de las antenas de tipo c con su rango respectivo
    elif type_new == 'd':
        print(max(0, math.ceil((area - area_old * ant_old) / 14700)))
    elif type_new == 'e':
        print(max(0, math.ceil(   )))  # Aqui debes realizar el calculo de las antenas de tipo e con su rango respectivo
    else:
        print('error en los datos')
else:
    print('error en los datos')