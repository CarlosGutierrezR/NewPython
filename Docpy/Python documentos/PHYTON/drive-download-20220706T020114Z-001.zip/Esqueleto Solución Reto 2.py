import math

n =  # Aqui debes leer la cantidad de zonas y transformarla a int
ant_a, ant_b, ant_c, ant_d, ant_e = 0, 0, 0, 0, 0

for i in range(n):
    area = float(input())
    ant_old =  # Aqui debes leer la cantidad de antenas previamente instaladas y transformarla a int
    type_new = input()
    area_old =  # Aqui debes asignar el valor del rango de las antenas previamente instaladas

    if ant_old >= 0:
        if type_new == 'a':
            ant_a += max(0, math.ceil(   ))  # Aqui debes realizar el calculo de las antenas de tipo a con su rango respectivo
        elif type_new == 'b':
            ant_b += max(0, math.ceil((area - area_old * ant_old) / 12600))
        elif type_new == 'c':
            ant_c += max(0, math.ceil(   ))  # Aqui debes realizar el calculo de las antenas de tipo c con su rango respectivo
        elif type_new == 'd':
            ant_d += max(0, math.ceil(   ))  # Aqui debes realizar el calculo de las antenas de tipo d con su rango respectivo
        elif type_new == 'e':
            ant_e += max(0, math.ceil((area - area_old * ant_old) / 38000))

ant_tot =   # Aqui debes realizar la suma de los 5 acumuladores de antenas

if ant_tot > 0:
    print(ant_tot)
    print('a {:.2f}%'.format(ant_a / ant_tot * 100))
    print('b {:.2f}%'.format(   ))  # Aqui debes realizar el calculo de la proporcion porcentual de antenas de tipo b
    print('c {:.2f}%'.format(ant_c / ant_tot * 100))
    print('d {:.2f}%'.format(   ))  # Aqui debes realizar el calculo de la proporcion porcentual de antenas de tipo d
    print('e {:.2f}%'.format(   ))  # Aqui debes realizar el calculo de la proporcion porcentual de antenas de tipo e
else:
    print(ant_tot)
    print('a 0.00%')
    print('b 0.00%')
    print('c 0.00%')
    print('d 0.00%')
    print('e 0.00%')